const express = require("express");
const NodeCache = require("node-cache");
const sportsConfig = require("../config/sports");
const { createClient } = require("../services/apiClient");
const { predictMatch } = require("../services/predictor");
const { updateRatings } = require("../services/eloEngine");

const router = express.Router();
const cache = new NodeCache();

function getSportConfig(sportKey) {
  const cfg = sportsConfig[sportKey];
  if (!cfg) {
    const err = new Error(`رياضة غير مدعومة: ${sportKey}`);
    err.status = 404;
    throw err;
  }
  return cfg;
}

// GET /api/sports -> قائمة كل الرياضات المتاحة في التطبيق
router.get("/sports", (req, res) => {
  const list = Object.entries(sportsConfig).map(([key, cfg]) => ({
    key,
    label: cfg.label,
  }));
  res.json({ sports: list });
});

// GET /api/live?sport=football -> المباريات الجارية الآن
router.get("/live", async (req, res, next) => {
  try {
    const sportKey = req.query.sport;
    const cfg = getSportConfig(sportKey);
    const cacheKey = `live:${sportKey}`;
    const cached = cache.get(cacheKey);
    if (cached) return res.json(cached);

    const client = createClient(cfg.host);
    const { data } = await client.get("/fixtures", { params: cfg.liveParam });

    const matches = (data.response || []).map((m) => normalizeFixture(m, sportKey));
    const payload = { sport: sportKey, matches };

    cache.set(cacheKey, payload, Number(process.env.CACHE_TTL_LIVE || 15));
    res.json(payload);
  } catch (err) {
    next(err);
  }
});

// GET /api/fixtures?sport=football&date=YYYY-MM-DD -> مباريات اليوم أو تاريخ معين
router.get("/fixtures", async (req, res, next) => {
  try {
    const sportKey = req.query.sport;
    const date = req.query.date || new Date().toISOString().slice(0, 10);
    const cfg = getSportConfig(sportKey);
    const cacheKey = `fixtures:${sportKey}:${date}`;
    const cached = cache.get(cacheKey);
    if (cached) return res.json(cached);

    const client = createClient(cfg.host);
    const { data } = await client.get("/fixtures", { params: { date } });

    const matches = (data.response || []).map((m) => normalizeFixture(m, sportKey));
    const payload = { sport: sportKey, date, matches };

    cache.set(cacheKey, payload, Number(process.env.CACHE_TTL_FIXTURES || 120));
    res.json(payload);
  } catch (err) {
    next(err);
  }
});

// GET /api/predict?sport=football&fixtureId=123&homeId=1&awayId=2
// ملاحظة: لازم تبعت homeId/awayId (بترجع من /fixtures أو /live) عشان يجيب الفورمة والتقييم
router.get("/predict", async (req, res, next) => {
  try {
    const { sport: sportKey, homeId, awayId } = req.query;
    const cfg = getSportConfig(sportKey);
    if (!homeId || !awayId) {
      return res.status(400).json({ error: "لازم تحدد homeId و awayId" });
    }

    const client = createClient(cfg.host);

    // نجيب آخر 5 نتائج لكل فريق لحساب الفورمة (endpoint متاح في أغلب رياضات API-Sports)
    const [homeFormRes, awayFormRes] = await Promise.all([
      client.get("/fixtures", { params: { team: homeId, last: 5 } }).catch(() => ({ data: { response: [] } })),
      client.get("/fixtures", { params: { team: awayId, last: 5 } }).catch(() => ({ data: { response: [] } })),
    ]);

    const homeForm = extractForm(homeFormRes.data.response, homeId);
    const awayForm = extractForm(awayFormRes.data.response, awayId);

    const prediction = predictMatch({
      sport: sportKey,
      homeTeamId: homeId,
      awayTeamId: awayId,
      homeForm,
      awayForm,
      hasDraw: cfg.hasDraw,
    });

    res.json(prediction);
  } catch (err) {
    next(err);
  }
});

// POST /api/results/sync  { sport, homeId, awayId, result }
// endpoint داخلي لتحديث تقييمات إيلو بعد انتهاء مباراة فعليًا (يُستدعى من مهمة مجدولة أو يدويًا)
router.post("/results/sync", express.json(), (req, res) => {
  const { sport, homeId, awayId, result } = req.body;
  if (!sport || !homeId || !awayId || result === undefined) {
    return res.status(400).json({ error: "بيانات ناقصة" });
  }
  const updated = updateRatings(sport, homeId, awayId, Number(result));
  res.json({ updated });
});

function normalizeFixture(raw, sportKey) {
  // API-Sports بيرجع شكل مختلف شوية بين رياضة وأخرى، فبنوحده هنا لأبسط شكل ممكن للواجهة
  const fixture = raw.fixture || raw.game || {};
  const teams = raw.teams || {};
  const goals = raw.goals || raw.scores || {};

  return {
    id: fixture.id || raw.id,
    status: fixture.status?.short || raw.status?.short || "NS",
    elapsed: fixture.status?.elapsed ?? null,
    date: fixture.date || raw.date,
    league: raw.league?.name || null,
    home: {
      id: teams.home?.id,
      name: teams.home?.name,
      logo: teams.home?.logo,
      score: goals.home ?? null,
    },
    away: {
      id: teams.away?.id,
      name: teams.away?.name,
      logo: teams.away?.logo,
      score: goals.away ?? null,
    },
  };
}

function extractForm(fixtures, teamId) {
  return (fixtures || [])
    .slice(0, 5)
    .map((f) => {
      const teams = f.teams || {};
      const goals = f.goals || f.scores || {};
      const isHome = String(teams.home?.id) === String(teamId);
      const teamGoals = isHome ? goals.home : goals.away;
      const oppGoals = isHome ? goals.away : goals.home;
      if (teamGoals == null || oppGoals == null) return "D";
      if (teamGoals > oppGoals) return "W";
      if (teamGoals < oppGoals) return "L";
      return "D";
    });
}

module.exports = router;
