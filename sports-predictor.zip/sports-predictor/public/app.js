const state = {
  sports: [],
  activeSport: null,
  view: "live", // live | today
  refreshTimer: null,
};

const el = {
  tabs: document.getElementById("sportTabs"),
  grid: document.getElementById("matchesGrid"),
  title: document.getElementById("sectionTitle"),
  ticker: document.getElementById("tickerTrack"),
  toggleBtns: document.querySelectorAll(".toggle-btn"),
};

init();

async function init() {
  await loadSports();
  el.toggleBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      el.toggleBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.view = btn.dataset.view;
      el.title.textContent = state.view === "live" ? "المباريات المباشرة الآن" : "مباريات اليوم";
      loadMatches();
    });
  });
}

async function loadSports() {
  try {
    const res = await fetch("/api/sports");
    const data = await res.json();
    state.sports = data.sports || [];
    renderTabs();
    if (state.sports.length) {
      state.activeSport = state.sports[0].key;
      selectSport(state.activeSport);
    }
  } catch (err) {
    el.grid.innerHTML = `<div class="empty-state">تعذر الاتصال بالسيرفر. تأكد إن الباك إند شغال.</div>`;
  }
}

function renderTabs() {
  el.tabs.innerHTML = "";
  state.sports.forEach((sport) => {
    const btn = document.createElement("button");
    btn.className = "sport-tab" + (sport.key === state.activeSport ? " active" : "");
    btn.textContent = sport.label;
    btn.addEventListener("click", () => selectSport(sport.key));
    el.tabs.appendChild(btn);
  });
}

function selectSport(key) {
  state.activeSport = key;
  [...el.tabs.children].forEach((btn, i) => {
    btn.classList.toggle("active", state.sports[i].key === key);
  });
  loadMatches();
  restartAutoRefresh();
}

function restartAutoRefresh() {
  if (state.refreshTimer) clearInterval(state.refreshTimer);
  state.refreshTimer = setInterval(() => {
    if (state.view === "live") loadMatches(true);
  }, 20000);
}

async function loadMatches(silent = false) {
  if (!silent) {
    el.grid.innerHTML = `<div class="empty-state">جارٍ التحميل…</div>`;
  }
  try {
    const endpoint =
      state.view === "live"
        ? `/api/live?sport=${state.activeSport}`
        : `/api/fixtures?sport=${state.activeSport}`;
    const res = await fetch(endpoint);
    const data = await res.json();
    renderMatches(data.matches || []);
    updateTicker(data.matches || []);
  } catch (err) {
    el.grid.innerHTML = `<div class="empty-state">حصل خطأ في جلب البيانات. جرّب تاني بعد شوية.</div>`;
  }
}

function renderMatches(matches) {
  if (!matches.length) {
    el.grid.innerHTML = `<div class="empty-state">مفيش مباريات ${state.view === "live" ? "مباشرة" : "اليوم"} في الرياضة دي حاليًا.</div>`;
    return;
  }

  el.grid.innerHTML = "";
  matches.forEach((m) => {
    const card = document.createElement("div");
    card.className = "match-card";
    const isLive = !["NS", "FT", "AOT", "CANC", "PST"].includes(m.status);

    card.innerHTML = `
      <div class="match-league">
        <span>${m.league || ""}</span>
        <span class="match-status ${isLive ? "" : "upcoming"}">
          ${isLive ? (m.elapsed ? m.elapsed + "'" : "مباشر") : statusLabel(m.status)}
        </span>
      </div>
      <div class="teams-row">
        <div class="team">${teamLogo(m.home)}<span>${m.home.name || "—"}</span></div>
        <div class="score">${scoreText(m)}</div>
        <div class="team" style="justify-content:flex-end; text-align:left;"><span>${m.away.name || "—"}</span>${teamLogo(m.away)}</div>
      </div>
      <button class="predict-btn" data-home="${m.home.id}" data-away="${m.away.id}">
        عرض التوقع الإحصائي
      </button>
      <div class="prediction-box"></div>
    `;

    const btn = card.querySelector(".predict-btn");
    btn.addEventListener("click", () => fetchPrediction(btn, card.querySelector(".prediction-box")));

    el.grid.appendChild(card);
  });
}

function teamLogo(team) {
  return team.logo ? `<img src="${team.logo}" alt="" onerror="this.style.display='none'" />` : "";
}

function scoreText(m) {
  if (m.home.score == null && m.away.score == null) return "vs";
  return `${m.home.score ?? 0} - ${m.away.score ?? 0}`;
}

function statusLabel(status) {
  const map = { NS: "لم تبدأ", FT: "انتهت", PST: "مؤجلة", CANC: "ملغاة", AOT: "بعد الإطالة" };
  return map[status] || status;
}

async function fetchPrediction(btn, box) {
  const { home, away } = btn.dataset;
  if (!home || !away || home === "undefined" || away === "undefined") {
    box.classList.add("visible");
    box.innerHTML = `<p class="prediction-note">بيانات الفريقين غير مكتملة من مزود البيانات لهذه المباراة.</p>`;
    return;
  }
  btn.disabled = true;
  btn.textContent = "جارٍ الحساب…";
  try {
    const res = await fetch(`/api/predict?sport=${state.activeSport}&homeId=${home}&awayId=${away}`);
    const p = await res.json();
    renderPrediction(box, p);
    btn.remove();
  } catch (err) {
    box.classList.add("visible");
    box.innerHTML = `<p class="prediction-note">تعذر حساب التوقع الآن.</p>`;
    btn.disabled = false;
    btn.textContent = "عرض التوقع الإحصائي";
  }
}

function renderPrediction(box, p) {
  box.classList.add("visible");
  const draw = p.drawProb != null;
  box.innerHTML = `
    <div class="prob-bar">
      <div class="prob-seg home" style="width:${p.homeWinProb}%"></div>
      ${draw ? `<div class="prob-seg draw" style="width:${p.drawProb}%"></div>` : ""}
      <div class="prob-seg away" style="width:${p.awayWinProb}%"></div>
    </div>
    <div class="prob-labels">
      <span>فوز المستضيف <b>${p.homeWinProb}%</b></span>
      ${draw ? `<span>تعادل <b>${p.drawProb}%</b></span>` : ""}
      <span>فوز الضيف <b>${p.awayWinProb}%</b></span>
    </div>
    <p class="prediction-note">الثقة: ${p.confidence} — ${p.disclaimer}</p>
  `;
}

function updateTicker(matches) {
  const liveOnes = matches.filter((m) => !["NS", "FT", "PST", "CANC"].includes(m.status));
  if (!liveOnes.length) {
    el.ticker.innerHTML = `<span class="ticker-item">مفيش مباريات مباشرة دلوقتي في الرياضة المختارة</span>`;
    return;
  }
  const items = liveOnes
    .map((m) => `<span class="ticker-item">${m.home.name} <b>${m.home.score ?? 0} - ${m.away.score ?? 0}</b> ${m.away.name}</span>`)
    .join("");
  // بنكرر القائمة مرتين عشان التمرير يبقى متصل من غير قطع
  el.ticker.innerHTML = items + items;
}
