// كل رياضة هنا معرّفة بمزود بيانات API-Sports (شبكة واحدة بتغطي رياضات متعددة
// بنفس نظام المفتاح). لو حبيت تضيف مزود تاني لرياضة معينة، ضيفها هنا فقط
// وباقي الكود (routes/services) هيتعامل معاها تلقائي.

module.exports = {
  football: {
    label: "كرة القدم",
    host: "v3.football.api-sports.io",
    hasDraw: true,
    liveParam: { live: "all" },
  },
  basketball: {
    label: "كرة السلة",
    host: "v1.basketball.api-sports.io",
    hasDraw: false,
    liveParam: { live: "all" },
  },
  volleyball: {
    label: "الكرة الطائرة",
    host: "v1.volleyball.api-sports.io",
    hasDraw: false,
    liveParam: { live: "all" },
  },
  handball: {
    label: "كرة اليد",
    host: "v1.handball.api-sports.io",
    hasDraw: false,
    liveParam: { live: "all" },
  },
  hockey: {
    label: "الهوكي",
    host: "v1.hockey.api-sports.io",
    hasDraw: false,
    liveParam: { live: "all" },
  },
  rugby: {
    label: "الرجبي",
    host: "v1.rugby.api-sports.io",
    hasDraw: false,
    liveParam: { live: "all" },
  },
  baseball: {
    label: "البيسبول",
    host: "v1.baseball.api-sports.io",
    hasDraw: false,
    liveParam: { live: "all" },
  },
  americanFootball: {
    label: "الفوتبول الأمريكي",
    host: "v1.american-football.api-sports.io",
    hasDraw: false,
    liveParam: { live: "all" },
  },
};
