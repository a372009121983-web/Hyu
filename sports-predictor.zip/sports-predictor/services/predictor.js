const { expectedScore, getRatings } = require("./eloEngine");

const HOME_ADVANTAGE = 60; // نقاط إيلو إضافية للفريق صاحب الأرض
const DRAW_BAND = 40; // مدى فرق التقييم اللي بيدي احتمال تعادل معقول

/**
 * بيحول نتائج آخر المباريات (W/D/L) لمعامل "فورمة" من -1 إلى 1
 * form: مصفوفة زي ["W","W","D","L","W"] أحدث نتيجة أولًا
 */
function formScore(form = []) {
  if (!form.length) return 0;
  const weights = [1, 0.85, 0.7, 0.55, 0.4]; // أحدث نتيجة ليها وزن أعلى
  let total = 0;
  let weightSum = 0;
  form.slice(0, 5).forEach((res, i) => {
    const w = weights[i] ?? 0.3;
    const val = res === "W" ? 1 : res === "D" ? 0 : -1;
    total += val * w;
    weightSum += w;
  });
  return weightSum ? total / weightSum : 0;
}

/**
 * الدالة الرئيسية: بتاخد بيانات المباراة وترجع احتمالات مبنية على:
 * 1) تقييم إيلو للفريقين (تاريخ النتائج المتراكم)
 * 2) الفورمة الأخيرة لكل فريق
 * 3) أفضلية أرض الملعب
 * 4) المواجهات المباشرة السابقة (اختياري لو متوفرة)
 *
 * النتيجة احتمالية تقريبية، مش توقع مضمون.
 */
function predictMatch({
  sport,
  homeTeamId,
  awayTeamId,
  homeForm = [],
  awayForm = [],
  headToHead = null, // { homeWins, draws, awayWins } لو متاحة
  hasDraw = true,
}) {
  const ratings = getRatings(sport, [homeTeamId, awayTeamId]);
  const homeElo = ratings[homeTeamId];
  const awayElo = ratings[awayTeamId];

  // تعديل بسيط للتقييم بناءً على الفورمة الحالية (±50 نقطة كحد أقصى)
  const homeAdj = homeElo + HOME_ADVANTAGE + formScore(homeForm) * 50;
  const awayAdj = awayElo + formScore(awayForm) * 50;

  let pHome = expectedScore(homeAdj, awayAdj);
  let pAway = 1 - pHome;
  let pDraw = 0;

  if (hasDraw) {
    // كل ما فرق القوة بين الفريقين أقل، احتمال التعادل أعلى
    const eloGap = Math.abs(homeAdj - awayAdj);
    pDraw = Math.max(0.12, 0.32 - eloGap / (DRAW_BAND * 10));
    pHome = pHome * (1 - pDraw);
    pAway = pAway * (1 - pDraw);
  }

  // تعديل خفيف حسب المواجهات المباشرة لو متوفرة
  if (headToHead) {
    const { homeWins = 0, draws = 0, awayWins = 0 } = headToHead;
    const total = homeWins + draws + awayWins;
    if (total >= 3) {
      const h2hHomeRate = homeWins / total;
      const h2hAwayRate = awayWins / total;
      pHome = pHome * 0.85 + h2hHomeRate * 0.15;
      pAway = pAway * 0.85 + h2hAwayRate * 0.15;
      if (hasDraw) pDraw = Math.max(0, 1 - pHome - pAway);
    }
  }

  // تطبيع النسب عشان مجموعها 100%
  const sum = pHome + pDraw + pAway;
  pHome /= sum;
  pDraw /= sum;
  pAway /= sum;

  // مؤشر ثقة: كل ما احتمال أعلى نتيجة أكبر، الثقة أعلى (مش دقة مضمونة)
  const top = Math.max(pHome, pDraw, pAway);
  const confidence = top > 0.55 ? "مرتفعة نسبيًا" : top > 0.4 ? "متوسطة" : "منخفضة (مباراة متقاربة)";

  return {
    homeWinProb: round(pHome),
    drawProb: hasDraw ? round(pDraw) : null,
    awayWinProb: round(pAway),
    confidence,
    ratings: { home: Math.round(homeElo), away: Math.round(awayElo) },
    disclaimer: "توقع إحصائي تقريبي بناءً على البيانات التاريخية والفورمة، وليس نتيجة مضمونة.",
  };
}

function round(x) {
  return Math.round(x * 1000) / 10; // نسبة مئوية بمنزلة عشرية واحدة
}

module.exports = { predictMatch, formScore };
