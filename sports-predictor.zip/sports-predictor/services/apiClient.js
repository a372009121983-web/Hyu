const axios = require("axios");

/**
 * بيعمل axios instance مضبوط لأي رياضة بناءً على الـ host بتاعها.
 * كل الرياضات في API-Sports بتستخدم نفس نظام الهيدر والمفتاح.
 */
function createClient(host) {
  return axios.create({
    baseURL: `https://${host}`,
    headers: {
      "x-apisports-key": process.env.API_SPORTS_KEY || "",
    },
    timeout: 10000,
  });
}

module.exports = { createClient };
