const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "..", "data");
const DEFAULT_RATING = 1500;
const K_FACTOR = 24;

function fileFor(sport) {
  return path.join(DATA_DIR, `elo-${sport}.json`);
}

function loadRatings(sport) {
  const file = fileFor(sport);
  if (!fs.existsSync(file)) return {};
  try {
    return JSON.parse(fs.readFileSync(file, "utf-8"));
  } catch {
    return {};
  }
}

function saveRatings(sport, ratings) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(fileFor(sport), JSON.stringify(ratings, null, 2));
}

function getRating(sport, teamId) {
  const ratings = loadRatings(sport);
  return ratings[teamId] ?? DEFAULT_RATING;
}

function getRatings(sport, teamIds) {
  const ratings = loadRatings(sport);
  const result = {};
  teamIds.forEach((id) => {
    result[id] = ratings[id] ?? DEFAULT_RATING;
  });
  return result;
}

/**
 * expectedScore: احتمالية فوز الفريق A حسب فرق التقييمات (نظرية إيلو الكلاسيكية)
 */
function expectedScore(ratingA, ratingB) {
  return 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
}

/**
 * بيحدّث تقييمات الفريقين بعد نتيجة فعلية.
 * result: 1 = فوز الفريق الأول، 0.5 = تعادل، 0 = خسارة الفريق الأول
 */
function updateRatings(sport, homeTeamId, awayTeamId, result, homeAdvantage = 60) {
  const ratings = loadRatings(sport);
  const homeRating = ratings[homeTeamId] ?? DEFAULT_RATING;
  const awayRating = ratings[awayTeamId] ?? DEFAULT_RATING;

  const expectedHome = expectedScore(homeRating + homeAdvantage, awayRating);
  const expectedAway = 1 - expectedHome;

  ratings[homeTeamId] = Math.round(homeRating + K_FACTOR * (result - expectedHome));
  ratings[awayTeamId] = Math.round(awayRating + K_FACTOR * ((1 - result) - expectedAway));

  saveRatings(sport, ratings);
  return { home: ratings[homeTeamId], away: ratings[awayTeamId] };
}

module.exports = { getRating, getRatings, expectedScore, updateRatings, DEFAULT_RATING };
