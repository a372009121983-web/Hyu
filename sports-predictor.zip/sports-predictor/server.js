require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const apiRouter = require("./routes/api");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.use("/api", apiRouter);

// معالج أخطاء موحّد
app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(err.status || 500).json({ error: err.message || "خطأ غير متوقع في السيرفر" });
});

app.listen(PORT, () => {
  console.log(`✅ السيرفر شغال على http://localhost:${PORT}`);
  if (!process.env.API_SPORTS_KEY) {
    console.warn("⚠️  تحذير: API_SPORTS_KEY مش موجود في .env — البيانات مش هتشتغل من غير مفتاح حقيقي.");
  }
});
